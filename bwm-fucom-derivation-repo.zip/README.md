# Deriving BWM and FUCOM weights from AHP pairwise comparison matrices

[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/karman09/ahp-bwm-fucom-derivation/blob/main/run_in_colab.ipynb)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.<id>.svg)](https://doi.org/10.5281/zenodo.<id>)

Code accompanying the article

> [Authors]. Deriving BWM and FUCOM weights from AHP pairwise comparison matrices. *Omega* (under review).

The code extracts the Best-Worst Method (BWM) and Full Consistency Method (FUCOM) inputs from a complete
Analytic Hierarchy Process (AHP) pairwise comparison matrix, solves both models and compares the derived
weights with those reported in seven published cases. It also runs the robustness analyses and the Monte
Carlo simulation reported in the article.

## Contents

| File | Purpose | Article |
|---|---|---|
| `bwm_fucom_derivation.py` | `MCDM_Extractor` class, data of the seven published cases, agreement measures, main tables and figures | Sections 3–4.5, Tables 1–5, A1–A8, B1–B7, Figs. 1–3 |
| `robustness_analyses.py` | Input-based consistency ratio, sensitivity to the choice of best/worst criteria, Monte Carlo simulation | Sections 3.8, 4.6–4.7, Table 6, Table A9, Fig. 4 |
| `run_in_colab.ipynb` | Runs both scripts in Google Colab without installation | – |
| `requirements.txt` | Python dependencies | – |

## Running the code

**Google Colab (no installation):** click the *Open in Colab* badge above and select *Runtime → Run all*.

**Locally (Python ≥ 3.10):**

```bash
git clone https://github.com/karman09/ahp-bwm-fucom-derivation.git
cd ahp-bwm-fucom-derivation
pip install -r requirements.txt
python bwm_fucom_derivation.py      # published cases: console report, figures, BWM_FUCOM_Derivation_Report.xlsx
python robustness_analyses.py       # robustness analyses and simulation: figure_simulation.*, Robustness_Report.xlsx
```

`robustness_analyses.py` loads the extractor and the case data from `bwm_fucom_derivation.py`, which must be in
the same folder. The simulation (18,000 matrices, fixed seed 2026) takes a few minutes; with the fixed seed,
all reported values are reproduced exactly.

## Outputs

- `BWM_FUCOM_Derivation_Report.xlsx` – summary, manuscript tables and one sheet per case
- `Robustness_Report.xlsx` – sheets `InputCR`, `BW_Sensitivity`, `Simulation_Summary`, `Simulation_Raw`, `Simulation_Ties`
- `Figure_1`–`Figure_3` and `figure_simulation` in SVG, PDF and PNG (and TIFF for Figures 1–3)
- `figure_case1.png` … `figure_case7.png` – one diagnostic figure per case

## Data

All pairwise comparison matrices and reported weights are transcribed from the published sources cited in the
article (Pamučar et al., 2018; Ekin and Sarul, 2022; Mercan and Acıbuca, 2025; Badi and Abdulshahed, 2019;
Badi et al., 2023; Vujović et al., 2025). Deviations from the printed sources (the transposed entries of Case 1
and the aggregation used in Case 6) are documented in the code comments and in the article.

## Citation

If you use this code, please cite the article above and the archived version of the code:

> [Authors] (2026). Code for "Deriving BWM and FUCOM weights from AHP pairwise comparison matrices" (Version 1.0) [Software]. Zenodo. https://doi.org/10.5281/zenodo.<id>

## License

MIT License (see `LICENSE`).
